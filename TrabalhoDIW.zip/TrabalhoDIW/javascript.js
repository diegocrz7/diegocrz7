function filtro(){
    var textoParaFiltrar = document.getElementById("textoFiltro").value;
    filtrar(textoParaFiltrar);
}

function filtrar(texto){

    var areaComNomeDoFiltro = document.getElementById("cardsProdutos");
    var cartoes = document.getElementsByClassName("card");
    var filme;
    for(let i = 0; i < cartoes.length; i++){
        filme = cartoes[i];
        filme.style.display="flex"
    }

    if(texto.length>0){
        areaComNomeDoFiltro.style.display="block";
        areaComNomeDoFiltro.textContent = "Filtrado por "+texto;
        limparFormulario();
       
        for(let i = 0; i < cartoes.length; i++){
            filme = cartoes[i];
            var paragrafo = filme.getElementsByClassName("generos").item(0);
            var generos = paragrafo.textContent.toLowerCase();

            if(!generos.includes(texto.toLowerCase())){
                filme.style.display="none"
            }
        }
    }
    else {
        areaComNomeDoFiltro.style.display="none";    
    }

}

function limparFormulario(){
    var areaTexto = document.getElementById("pesquisar");
    areaTexto.value="";
}