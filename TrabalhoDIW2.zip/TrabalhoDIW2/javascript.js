const vaz = document.getElementById(`textoVaz`);
function hide(){
    for(let i=1;i<=15;i++){
        document.getElementById(`prodcar${i}`).style.display = "none";
    }
    var main=document.querySelector("html")
    main.style["overflow-y"] = "hidden";
    document.getElementById(`ProPag`).style.display = "none";
}

function show(pesq){
    var pesq =16;
    if(pesq==0){
        vaz.setAttribute("style", "visibility: visible;");
    }
    else if(pesq>15){
        vaz.setAttribute("style", "visibility: hidden;");
        for(let i=1;i<=15;i++){
            document.getElementById(`prodcar${i}`).style.display = "grid";
        }
        var main=document.querySelector("html")
        main.style["overflow-y"] = "visible";
        document.getElementById(`ProPag`).style.display = "block";
        console.log("Aqui roda")
        lerAPI()
    }
    else{
     vaz.setAttribute("style", "visibility: hidden;");
    for(let i=1;i<=pesq;i++){
        document.getElementById(`prodcar${i}`).style.display = "grid";
    }
    var main=document.querySelector("html")
    main.style["overflow-y"] = "visible";
    lerAPI()
    }
}

async function lerAPI(){
    let produtosAPI = await fetch('https://fakestoreapi.com/products')
    produtosAPI = await produtosAPI.json()
    console.log(produtosAPI)
    serPag(produtosAPI)
}    
function serPag(produtosAPI){
    var pesq=16
    for(let i=1;i<=pesq;i++){
        document.getElementById(`prodcar${i}`).innerHTML+= `<img src=${produtosAPI[i]['image']} class="prod${i}"> 
        <p class="prodTit1">${produtosAPI[i]['title']}</p>
        <p class="precoProd1">R$${produtosAPI[i]['price']}</p>`
    }
}

async function loadCard(){
    async function lerAPI(){
        let produtosAPI = await fetch('https://fakestoreapi.com/products')
        produtosAPI = await produtosAPI.json()
        console.log(produtosAPI)
        changeCard(produtosAPI)
    }    
    function changeCard(produtosAPI){
        for(let i=1;i<10;i++){
            document.getElementById(`CARD${i}`).innerHTML+= 
            `<div class="card"  id="Cards">
                <img src="${produtosAPI[i]['image']}" class="card-img-top" alt="" id="imCa">
                <div class="card-body">
                    <h5 class="card-title" id="TiCr">${produtosAPI[i]['title']}</h5>
                    <p class="card-text">R$${produtosAPI[i]['price']}</p>
                    <p class="estrelasCard"><i class='fas fa-star'></i>
                        <i class='fas fa-star'></i>
                        <i class='fas fa-star'></i>
                        <i class='fas fa-star'></i>
                        <i class='fas fa-star'></i></p>
                    <a href="#" class="btn btn-primary" id="botaoComprar">Comprar</a>
                </div>
            </div>`
        console.log(document.getElementById(`CARD${i}`))
        }
    }
    lerAPI()
}

fetch('https://fakestoreapi.com/products/1')
    .then(res=>prod=res.json())
    .then(function change(prod){
        var count;
        var descri;
        count=prod['rating']['count']
        descri=prod['description']
        var img=prod['image']
        var pri=prod['price']
        var ti=prod['title']
                
    const star1 = document.getElementById('st1')
    const star2 = document.getElementById('st2')
    const star3 = document.getElementById('st3')
    const star4 = document.getElementById('st4')
    const star5 = document.getElementById('st5')
    var clas=10;
    var gend="Fantasy, Isekai, ecchi";
    var yea=2014;
    var Aut="Fuse";
    if(clas==1){
        star1.className="fa-regular fa-star-half-stroke fa-2xl"
    }
        else if(clas==2){
            star1.className="fas fa-star fa-2xl"
        }

        else if(clas==3){
            star1.className="fas fa-star fa-2xl"
            star2.className="fa-regular fa-star-half-stroke fa-2xl"
        }

        else if(clas==4){
            star1.className="fas fa-star fa-2xl"
            star2.className="fas fa-star fa-2xl"
        }

        else if(clas==5){
            star1.className="fas fa-star fa-2xl"
            star2.className="fas fa-star fa-2xl"
            star3.className="fa-regular fa-star-half-stroke fa-2xl"
        }

        else if(clas==6){
            star1.className="fas fa-star fa-2xl"
            star2.className="fas fa-star fa-2xl"
            star3.className="fas fa-star fa-2xl"
        }

        else if(clas==7){
            star1.className="fas fa-star fa-2xl"
            star2.className="fas fa-star fa-2xl"
            star3.className="fas fa-star fa-2xl"
            star4.className="fa-regular fa-star-half-stroke fa-2xl"
        }

        else if(clas==8){
            star1.className="fas fa-star fa-2xl"
            star2.className="fas fa-star fa-2xl"
            star3.className="fas fa-star fa-2xl"
            star4.className="fas fa-star fa-2xl"
        }

        else if(clas==9){
            star1.className="fas fa-star fa-2xl"
            star2.className="fas fa-star fa-2xl"
            star3.className="fas fa-star fa-2xl"
            star4.className="fas fa-star fa-2xl"
            star5.className="fa-regular fa-star-half-stroke fa-2xl"
        }

        else if(clas==10){
            star1.className="fas fa-star fa-2xl"
            star2.className="fas fa-star fa-2xl"
            star3.className="fas fa-star fa-2xl"
            star4.className="fas fa-star fa-2xl"
            star5.className="fas fa-star fa-2xl"
        }

        else if(clas<=0){
            star1.className="fa-regular fa-star fa-2xl"
            star2.className="fa-regular fa-star fa-2xl"
            star3.className="fa-regular fa-star fa-2xl"
            star4.className="fa-regular fa-star fa-2xl"
            star5.className="fa-regular fa-star fa-2xl"
        }

        else{
            star1.className="fas fa-star fa-2xl"
            star2.className="fas fa-star fa-2xl"
            star3.className="fas fa-star fa-2xl"
            star4.className="fas fa-star fa-2xl"
            star5.className="fas fa-star fa-2xl"
        }

    document.getElementById("count").textContent=`Votos ${count}`
    /* document.getElementById("gen").textContent=`Generos: ${gend}`
    document.getElementById("ye").textContent=`Ano de lançamento: ${yea}`
    document.getElementById("brand").textContent=`Autor: ${Aut}` */
    document.getElementById("descr").textContent=descri
    document.getElementById("im").src=img
    document.getElementById("titl").textContent=ti
    })
