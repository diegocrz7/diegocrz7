function detalharProduto(idFilme){
    
    let requisicao = 'http://my-json-server.typicode.com/joaocaram/DIW/filmes?id='+idFilme
    fetch(requisicao)
    .then(resposta => resposta.json())
    .then(dados => mostrar(dados))
   
}

function mostrar(filmeAtual){
    var conteudoPrincipal = document.getElementById("principal");
    var htmlFilmes = "";
    
    var cartaoFilme = 
                    `<article class="card mx-2 my-1 p-2 w-100" >
                        <div class="dadosFilme flex-wrap">
                            <img src="img/${filmeAtual[0].cartaz}" class="card-img-top" alt="${filmeAtual[0].titulo}">
                            <div class="card-body">
                                <h5 class="card-title"><a href="./detalhes.html?id=${filmeAtual[0].id}">${filmeAtual[0].titulo}</a></h5>
                                <p class="card-text generos">Gêneros: ${filmeAtual[0].generos}</p>
                                <p class="card-text generos">País de origem: ${filmeAtual[0].pais}</p>
                                <p class="card-text sinopse">${filmeAtual[0].sinopse}</p>
                            </div>
                        </div>
                    </article>`;
        htmlFilmes += cartaoFilme;
    
    conteudoPrincipal.innerHTML += htmlFilmes;    
}

window.onload = () =>{
    let idParametro = new URLSearchParams(window.location.search);
    let identificador = idParametro.get("id");
    detalharProduto(identificador);
}